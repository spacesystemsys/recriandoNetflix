Desafio

Desafio proposto pela escola de programação Digital Innovations 
recriando a pagina do netflix.

https://eustaquiofreitas.github.io/desafio-recriando-netflix/